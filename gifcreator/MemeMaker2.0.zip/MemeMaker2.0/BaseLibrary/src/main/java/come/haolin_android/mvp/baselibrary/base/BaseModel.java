package come.haolin_android.mvp.baselibrary.base;

public class BaseModel {
}
