package come.haolin_android.mvp.baselibrary.base;

public interface BaseView {

}
