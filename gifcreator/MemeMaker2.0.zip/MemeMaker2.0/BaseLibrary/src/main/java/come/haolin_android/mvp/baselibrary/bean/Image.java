package come.haolin_android.mvp.baselibrary.bean;

import android.os.Parcelable;

public interface Image extends Parcelable {

    String getImageUrl();
}
