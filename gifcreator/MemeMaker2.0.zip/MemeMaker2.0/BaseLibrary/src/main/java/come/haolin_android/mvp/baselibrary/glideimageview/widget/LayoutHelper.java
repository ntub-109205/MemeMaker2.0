package come.haolin_android.mvp.baselibrary.glideimageview.widget;

import android.graphics.Point;

/**
 * @author sunfusheng on 2018/6/19.
 */
public interface LayoutHelper {
    Point getCoordinate(int position);

    Point getSize(int position);
}
