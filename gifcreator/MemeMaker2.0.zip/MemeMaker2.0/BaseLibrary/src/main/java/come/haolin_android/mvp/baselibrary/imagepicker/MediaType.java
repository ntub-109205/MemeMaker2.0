package come.haolin_android.mvp.baselibrary.imagepicker;

public enum  MediaType {
    VIDEO,
    IMAGE
}
