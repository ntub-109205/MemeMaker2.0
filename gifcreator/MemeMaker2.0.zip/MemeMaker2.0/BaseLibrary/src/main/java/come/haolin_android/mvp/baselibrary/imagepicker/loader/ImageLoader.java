package come.haolin_android.mvp.baselibrary.imagepicker.loader;

import come.haolin_android.mvp.baselibrary.imagepicker.photo.PhotoView;

/**
 * author  : Hacknife
 * e-mail  : 4884280@qq.com
 * github  : http://github.com/hacknife
 * project : MediaPicker
 */
public interface ImageLoader {


    void displayFileImage(PhotoView imageView, String path);

    void displayUserImage(PhotoView imageView, String path);

    void displayFileVideo(String path);


    Class<?> displayFullImageClass();
}
