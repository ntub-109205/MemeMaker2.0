package come.haolin_android.mvp.baselibrary.networkmonitoring.type;

public enum NetType {


    //只要有网络
    AUTO,
    //
    WIFI,
    //pc 笔记本电脑 pad设备
    CMNET,
    //手机上网
    CMWAP,
    //没有网络
    NONE
}
