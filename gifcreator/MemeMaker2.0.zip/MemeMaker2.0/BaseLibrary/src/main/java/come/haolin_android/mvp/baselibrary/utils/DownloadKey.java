package come.haolin_android.mvp.baselibrary.utils;

import android.content.Context;

public class DownloadKey {
    @Deprecated
    public static Context FROMACTIVITY = null;
    public static String apkUrl;
    public static String changeLog = "";
    public static String version;
    public static String APPSize;
    public static boolean interceptFlag = false;//是否强制更新
}
