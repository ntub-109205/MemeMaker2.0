package com.deep.photoeditor;

public class tagSearch {
    private String tag;

    public tagSearch() {
    }

    public tagSearch(String tag) {
        this.tag = tag;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }
}
