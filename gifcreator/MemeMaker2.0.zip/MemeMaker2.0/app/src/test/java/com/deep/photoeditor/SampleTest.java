package com.deep.photoeditor;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class SampleTest {

    @Test
    public void testAddition() {
        assertEquals(6, 3 + 3);
    }

}